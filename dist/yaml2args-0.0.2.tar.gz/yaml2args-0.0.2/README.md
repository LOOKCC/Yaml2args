# Yaml to args
A Sample code for you to update your yaml config to args.
## Usage
See example.py

